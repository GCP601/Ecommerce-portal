import Fastify, { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { fileReadPath, readFileAsync, productListAsync } from './aula_01_funcs';
import { getProduto, newProduto, updateProduto, updateProdutoImg, deleteProduto } from './aula_02_funcs'
import { GetItemParams, CreateProdutoBody, UpdateProdutoParams, UpdateProdutoBody, UpdateProdutoImgBody, DeleteProdutoParams } from './interfaces'
import { post_schema_opts } from './aula_02_schemas';
import Product from './Product';

async function routes (fastify: FastifyInstance, options: any) {

  // ***************************************************************************
  // ********************           ROTAS COMUNS            ********************
  // ***************************************************************************

  // GET para listar todos os produtos
  fastify.get('/produtos', async (request, reply) => {
    const data = await readFileAsync(fileReadPath);
    const productList = await productListAsync(data);
    return productList;
  });

  // GET para obter product por id específico
  fastify.get<{ Params: GetItemParams }>('/produtos/:id', async (request, reply) => {
    const id = request.params.id;
    const produto = await getProduto(id);
    if (!produto){
      reply.code(404).send({ error: 'Item não encontrado!' });
    }
    return produto;
  });

  // POST para a criação de um novo produto
  fastify.post<{ Body: CreateProdutoBody }>('/produtos', async (request, reply) => {
    const novoProdutoDados = request.body;
    const produtoCriado = await newProduto(novoProdutoDados);
    reply.code(201).send(produtoCriado);
  });

  // PUT para a atualização de um produto existente
  fastify.put<{ Params: UpdateProdutoParams, Body: UpdateProdutoBody}>('/produtos/:id', async(request, reply) => {
    const produtoId = request.params.id;
    const produtoDados = request.body;
    const produtoAtualizado = await updateProduto(produtoId, produtoDados);
    if (!produtoAtualizado){
      reply.code(404).send({ error: 'Item não encontrado para atualização!' });
    }
    return produtoAtualizado;
  });

  // PUT definindo a imagem de um produto
  fastify.put<{ Params: UpdateProdutoParams, Body: UpdateProdutoImgBody}>('/produtos/:id/newimg', async(request, reply) => {
    const produtoId = request.params.id;
    const produtoImg = request.body;
    const produtoAtualizado = await updateProdutoImg(produtoId, produtoImg);
    if (!produtoAtualizado){
      reply.code(404).send({ error: 'Item não encontrado para atualização!' });
    }
    return produtoAtualizado;
  });

  // DELETE para remover um produtor
  fastify.delete<{ Params: DeleteProdutoParams }>('/produtos/:id', async(request, reply) => {
    const id = request.params.id;
    const success = await deleteProduto(id);
    if (!success){
      reply.code(404).send({ error: 'Item não encontrado para deletar!' });
    }
    reply.code(204).send();
  });

  // ***************************************************************************
  // ********************        APLICAÇÃO DE SCHEMA        ********************
  // ***************************************************************************
  // POST para a criação de um novo produto utilizando schema
  fastify.post('/produtos_schema', post_schema_opts, async (request, reply) => {
    const novoProdutoDados: Product = request.body as Product;
    const produtoCriado = await newProduto(novoProdutoDados);
    return { message: `Produto ${produtoCriado.name} criado.` };
  });
}
  
export default routes;
