import * as fs from 'fs/promises';
import Product from './Product';
import axios from 'axios';

const fileReadPath = 'base/products.json';
const fileWritePath = 'base/processed.json';

type ProductAllowed = {
  id: number;
  name: string;
}

async function readFileAsync(filePath: string): Promise<string> {
  const data = fs.readFile(filePath, 'utf-8');
  return data;
}

async function productListAsync(data: string): Promise<Product[]> {
  const arrayJson = JSON.parse(data);
  return arrayJson;
}

async function productListAllowedAsync(productList: Product[]): Promise<Product[]> {
  let i: number = productList.length;
  while (i--) {
    let url: string = 'https://posdesweb.igormaldonado.com.br/api/allowedCategory?category=' + String(productList[i].category);
    const response = await axios.get(url); //getRespServer(url)
    let allowed: boolean = response.data.allowed;
    if (!allowed) { 
      productList.splice(i, 1);
    }

  }
  return productList;
}

async function productListWritedAsync(productList: Product[]): Promise<String> {
  let i: number = 0;
  let productAllowedList = [];

  while (i < productList.length) {
    let productAllowed: ProductAllowed = {id: productList[i].id, name: productList[i].name};
    productAllowedList.push(productAllowed);
    i++;
  }
  
  let productAllowedListString = JSON.stringify(productAllowedList, null, 2);
  await fs.writeFile(fileWritePath, productAllowedListString, 'utf8');
  
  return productAllowedListString;
}

async function processFile(filePath: string): Promise<void> {
  try {
    const data = await readFileAsync(filePath);
    const productList = await productListAsync(data);
    const productListAllowed = await productListAllowedAsync(productList);
    const productListWrited = await productListWritedAsync(productListAllowed);
    console.log(productListWrited);
  } catch (err) {
    console.error("Erro encontrado: ", err);
  }
}

export { fileReadPath, processFile, readFileAsync, productListAsync };
