import { fileReadPath, processFile } from './aula_01_funcs';

processFile(fileReadPath);
