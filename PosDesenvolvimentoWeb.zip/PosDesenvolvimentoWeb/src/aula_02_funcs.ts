import * as fs from 'fs/promises';
import Product from './Product';
import { fileReadPath, readFileAsync, productListAsync } from './aula_01_funcs';
import { UpdateProdutoBody, UpdateProdutoImgBody } from './interfaces'

const fileWritePath = 'base/products.json';

async function getProduto(produto: number): Promise<any> {
    const data = await readFileAsync(fileReadPath);
    const productList = await productListAsync(data);
    let i: number = 0;
    while (i < productList.length) {
        if (productList[i].id == produto){
            return productList[i];
        }
        i++;
    }     
    return;
}

async function newProduto(produto: Product): Promise<Product> {
    const data = await readFileAsync(fileReadPath);
    const productList = await productListAsync(data);
    productList.push(produto);
    let productListString = JSON.stringify(productList, null, 2);
    await fs.writeFile(fileWritePath, productListString, 'utf8');
    //console.log(productList);
    return produto;
}

async function updateProduto(produtoId: number, produtoDados: UpdateProdutoBody): Promise<any> {
    const data = await readFileAsync(fileReadPath);
    const productList = await productListAsync(data);
    let i : number = 0;
    while (i < productList.length) {
        if (productList[i].id == produtoId){
            if (produtoDados.name){
                productList[i].name = produtoDados.name;
            }
            if (produtoDados.description){
                productList[i].description = produtoDados.description;
            }
            let productListString = JSON.stringify(productList, null, 2);
            await fs.writeFile(fileWritePath, productListString, 'utf8');
            return productList[i];
        }
        i++;
    }
    return;
}

async function updateProdutoImg(produtoId: number, produtoDados: UpdateProdutoImgBody): Promise<any> {
    const data = await readFileAsync(fileReadPath);
    const productList = await productListAsync(data);
    let i : number = 0;
    while (i < productList.length) {
        if (productList[i].id == produtoId){
            if (produtoDados.pictureUrl){
                productList[i].pictureUrl = produtoDados.pictureUrl;
            }
            let productListString = JSON.stringify(productList, null, 2);
            await fs.writeFile(fileWritePath, productListString, 'utf8');
            return productList[i];
        }
        i++;
    }
    return;
}

async function deleteProduto(produtoId: number): Promise<Boolean> {
    const data = await readFileAsync(fileReadPath);
    const productList = await productListAsync(data);
    let i : number = 0;
    while (i < productList.length) {
        if (productList[i].id == produtoId){
            productList.splice(i, 1);
            let productListString = JSON.stringify(productList, null, 2);
            await fs.writeFile(fileWritePath, productListString, 'utf8');
            return true;
        }
        i++;
    }
    return false;
}

export { getProduto, newProduto, updateProduto, updateProdutoImg, deleteProduto };
