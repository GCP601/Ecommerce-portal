import Fastify, { FastifyInstance, FastifyRequest, FastifyReply, fastify } from 'fastify';
import routes from './aula_02_routes';
import { onRequestHook } from './aula_02_hooks';

//import { request } from 'http';

/*
async function routes (fastify: FastifyInstance, options: any) {
  fastify.get('hello', async (request: FastifyRequest, reply: FastifyReply) => {
    return { message: 'Hello, world!' };
  });

  fastify.post('item', async (request: FastifyRequest, reply: FastifyReply) => {
    const item = request.body;
    return { message: 'Item created', item};
  });
}
*/

const server: FastifyInstance = Fastify({
  logger: true
});

server.addHook('onRequest', onRequestHook);

server.register(routes);

/*
server.get('/', async (request, reply) => {
  return { hello: 'world' };
});
*/
const start = async () => {
  try {
    await server.listen({ port: 3000 });
    server.log.info('Server listening on ${Server listening on ${server.server.address().port}');
  } catch (err) {
    server.log.error(err);
    process.exit(1);
  }
};

start();