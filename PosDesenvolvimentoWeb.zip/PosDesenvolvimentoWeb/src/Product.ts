export default class Product {
    /*
    Posso inicializar as variáveis direto ou criar um construtor
    */
    id: number = 0;
    name: string = "";
    description: string = "";
    price: number = 0;
    category: string = "";
    pictureUrl: string = "";

    /*
    Posso criar um constructor como abaixo desde que eu não inicialize as variáveis
    */
   /*
    constructor(id: number, name : string, description : string, price : number, category : string, pictureUrl : string) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.category = category;
        this.pictureUrl = pictureUrl;
    }
    */
}