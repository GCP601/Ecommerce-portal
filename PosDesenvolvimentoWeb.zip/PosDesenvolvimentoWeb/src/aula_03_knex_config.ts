//const knex = require('knex');
//import { Knex, knex } from "knex";

import knex from 'knex'; // Importa o Knex

// Define as configurações do Knex
const knexConfig = {
    client: 'pg',
    connection: {
        host: '127.0.0.1',
        user: 'postgres',
        password: 'postgres',
    },
    migrations: {
        extension: 'ts',
        tableName: 'knex-migrations',
        directory: './src/database/migrations'
    },
    seeds: {
        extension: 'ts',
        directory: './src/database/seeds'
    }    
};

// Cria a instância do Knex
const db = knex(knexConfig);

export { db, knexConfig};
