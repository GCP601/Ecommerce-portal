import { FastifyRequest, FastifyReply, HookHandlerDoneFunction } from 'fastify';

/**
 * Hook que é executado no início de cada requisição.
 * Ideal para logging, autenticação, ou pre-processamento de dados.
 * @param request Objeto de requisição do Fastify
 * @param reply Objeto de resposta do Fastify
 * @param done Função de callback para indicar que o hook foi concluído.
 */
export const onRequestHook = (
  request: FastifyRequest,
  reply: FastifyReply,
  done: HookHandlerDoneFunction
) => {
  console.log('--- onRequest Hook Executado ---');
  console.log(`Método: ${request.method}`);
  console.log(`URL: ${request.url}`);
  console.log(`Horário da Requisição: ${new Date().toISOString()}`);

  // Exemplo: Adicionar um carimbo de data/hora à requisição para uso posterior
  // Isso pode ser útil para medir o tempo de processamento da requisição
  (request as any).requestStartTime = Date.now();

  // Exemplo de verificação de autenticação (simplificado)
  // if (request.headers['x-api-key'] !== 'my-secret-key') {
  //   reply.status(401).send({ message: 'Unauthorized: Invalid API Key' });
  //   return; // Importante: retornar para não chamar done() e parar o pipeline
  // }

  console.log('---------------------------------');
  done(); // Chama a próxima função no pipeline de hooks/rotas
};