const post_schema_opts = {
    schema: {
        body: {
            type: 'object',
            properties: {
                id: { type: 'integer' },
                name: { type: 'string' },
                description: { type: 'string' },
                price: { type: 'number', "multipleOf": 0.01 },
                category: { type: 'string' },
                pictureUrl: { type: 'string' }
            },
            required: [ 'id', 'name', 'description', 'price', 'category', 'pictureUrl' ]
        },
        response: {
            200: {
                type: 'object',
                properties: {
                    message: { type: 'string' }
                }
            }            
        }
    }
};

export { post_schema_opts };
