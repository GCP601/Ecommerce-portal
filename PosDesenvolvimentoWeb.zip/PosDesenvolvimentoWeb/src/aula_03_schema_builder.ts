import { Knex } from 'knex';
import { db, knexConfig } from './aula_03_knex_config';

export async function up(knex: Knex): Promise<void> {
    await knex.schema.createTable('produtos', (table) => {
        table.increments('id');//.primary().unique();
        table.string('name', 255).notNullable();
        table.string('description', 255);
        table.decimal('price', 10, 2).notNullable();
        table.string('category', 255);
        table.string('pictureUrl', 255);
    });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable('produtos');
}


/*
export async function up(knex: Knex): Promise<void> {
    return knex.schema.createTable("tasks", (table) => {
        table.increments("id").primary().unique();
        table.string("title").notNullable();
        table.string("description").notNullable();
        table.boolean("completed").notNullable().defaultTo(false);
        table.timestamp("created_at").defaultTo(knex.fn.now());
        table.timestamp("updated_at").defaultTo(knex.fn.now());
    });
}
*/