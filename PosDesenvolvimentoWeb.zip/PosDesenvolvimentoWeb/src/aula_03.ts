import { db } from "./aula_03_knex_config";

import { up, down } from "./aula_03_schema_builder";

//const cria = 
up(db);

//down(db);

