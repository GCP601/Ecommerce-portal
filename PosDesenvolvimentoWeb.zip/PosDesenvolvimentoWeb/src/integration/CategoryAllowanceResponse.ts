export interface CategoryAllowanceResponse {
  allowed: boolean
}