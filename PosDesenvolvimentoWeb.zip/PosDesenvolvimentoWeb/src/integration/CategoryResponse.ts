export interface CategoryResponse {
  category: string
  allowed: boolean
}