//import * as crypto from 'crypto';
import Fastify, { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { getProduto, newProduto, updateProduto, updateProdutoImg, deleteProduto } from './aula_02_funcs'
import { post_schema_opts } from './aula_02_schemas';
import Product from './Product';
import jwt from 'jsonwebtoken';
import * as dotenv from 'dotenv';
import { decode } from 'punycode';
import { error } from 'console';


// ***************************************************************************
// ****************        GERAÇÃO DA CHAVE JWT_SECRET        ****************
// ***************************************************************************
// Copiar o resultado na constante JWT_SECRET no arquivo .env
//const secretKey = crypto.randomBytes(64).toString('hex');
//console.log(secretKey);


// ***************************************************************************
// ********************        APLICAÇÃO DE SCHEMA        ********************
// ***************************************************************************

dotenv.config(); // Carrega as variáveis do .env

/*
interface JwtPayload {
    userId: number;
    email: string;
    role: string;
    permission?: string[];
}

class JwtService {
    private secret: string;
    private expiresIn: number;

    constructor() {
        this.secret = process.env.JWT_SECRET!;
        this.expiresIn = Number(process.env.JWT_EXPIRES_IN);// || '24h';
    }

    generateToken(payload: JwtPayload): string {
        const options: jwt.SignOptions = {
            expiresIn: this.expiresIn,
            issuer: process.env.JWT_ISSUER,
            audience: process.env.JWT_AUDIENCE,
            subject: payload.userId.toString()
        };

        return jwt.sign(payload, this.secret, options);
    }

    generateRefreshToken(userId: number): string {
        return jwt.sign(
            { userId, type: 'refresh' },
            this.secret,
            { expiresIn: '7d' }
        );
    }
}
    */

async function routes_aula_04 (fastify: FastifyInstance, options: any) {
  
    // POST para a criação de um novo produto utilizando schema
  fastify.post('/produtos_schema_jwt', post_schema_opts, async (request, reply) => {
    try {
      const authHeader = request.headers.authorization;

      if (!authHeader) {
        reply.code(401).send({ error: 'Authorization header required'});
        return;
      }

      if (!authHeader.startsWith('Bearer ')) {
        reply.code(401).send({ error: 'Bearer token required' });
        return;
      }

      const token = authHeader.substring(7);

      const decoded = jwt.verify(
          token,
          process.env.JWT_SECRET!
      ) as jwt.JwtPayload;

      if (decoded.user == 'admin' && decoded.senha == 'admin') {
        const novoProdutoDados: Product = request.body as Product;
        const produtoCriado = await newProduto(novoProdutoDados);
        return { message: `Produto ${produtoCriado.name} criado.` };
      } else {
        throw error;
      }

    } catch (error) {
      if (error instanceof jwt.TokenExpiredError) {
        reply.status(401).send({
          error: 'Token expired',
          code: 'TOKEN_EXPIRED'
        });
      } else if (error instanceof jwt.JsonWebTokenError) {
        reply.status(401).send({
          error: 'Invalid token',
          code: 'INVALID_TOKEN'
        });
      } else {
        reply.status(500).send({
          error: 'Authentication failed'
        });
      }
    }
  });

}


     /*     
import jwt from 'jsonwebtoken';
import * as dotenv from 'dotenv';

dotenv.config(); // Carrega as variáveis do .env
*/
// ***************************************************************************
// ********************        GERANDO TOKENS JWT         ********************
// ***************************************************************************

/*
interface JwtPayload {
    userId: number;
    email: string;
    role: string;
    permission?: string[];
}

class JwtService {
    private secret: string;
    private expiresIn: number;

    constructor() {
        this.secret = process.env.JWT_SECRET!;
        this.expiresIn = Number(process.env.JWT_EXPIRES_IN);// || '24h';
    }

    generateToken(payload: JwtPayload): string {
        const options: jwt.SignOptions = {
            expiresIn: this.expiresIn,
            issuer: process.env.JWT_ISSUER,
            audience: process.env.JWT_AUDIENCE,
            subject: payload.userId.toString()
        };

        return jwt.sign(payload, this.secret, options);
    }

    generateRefreshToken(userId: number): string {
        return jwt.sign(
            { userId, type: 'refresh' },
            this.secret,
            { expiresIn: '7d' }
        );
    }
}
    */

// ***************************************************************************
// ****************    VALIDANDO TOKENS JWT (AUTENTICAÇÃO)    ****************
// ***************************************************************************

/*
export const authMiddleware = (
    req: AuthenticatedRequest,
    res: Response,
    next: NextFunction
): void => {
    try {
        const authHeader = req.headers.authorization;

        if (!authHeader) {
            res.status(401).json({ error: 'Authorization header required'});
            return;
        }

        if (!authHeader.startswith('Bearer ')) {
            res.status(401).json({ error: 'Bearer token required' });
            return;
        }

        const token = authHeader.substring(7);

        const decoded = jwt.verify(
            token,
            process.env.JWT_SECRET!
        ) as jwt.JwtPayload;

        req.user = {
            userId: decoded.userId,
            email: decoded.email,
            role: decoded.role,
            permissions: decoded.permissions || []
        };

        next();
    } catch (error) {
        if (error instanceof jwt.TokenExpiredError) {
            res.status(401).json({
                error: 'Token expired',
                code: 'TOKEN_EXPIRED'
            });
        } else if (error instanceof jwt.JsonWebTokenError) {
            res.status(401).json({
                error: 'Invalid token',
                code: 'INVALID_TOKEN'
            });
        } else {
            res.status(500).json({
                error: 'Authentication failed'
            });

        }
    }
};
*/

// ***************************************************************************
// ****************    VALIDANDO TOKENS JWT (AUTORIZAÇÃO)     ****************
// ***************************************************************************

/*
export const requiredRole = (allowedRoles: string | string[]) => {
    return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
        if (!req.user) {
            res.status(401).json({ error: 'Authentication required' });
            return;
        }

        const roles = Array.isArray(allowedRoles) ? allowedRoles : [allowedRoles];

        if (!roles.includes(req.user.role)) {
            res.status(403).json({
                error: 'Insufficient permissions',
                required: roles,
                current: req.user.role
            });
            return;
        }

        next();
    };
};

export const requiredPermission = (permission: string) => {
    return (req: AuthenticatedRequest, res: Response, nextFunction): void => {
        if (!req.user) {
            res.status(401).json({ error: 'Authentication required' });
            return;
        }

        if (!req.user.permissions.includes(permission)) {
            res.status(403).json({
                error: 'Permission denied',
                required: permission,
                current: req.user.permissions
            });
            return;
        }

        next();
    }
};
*/

export { routes_aula_04 }; 